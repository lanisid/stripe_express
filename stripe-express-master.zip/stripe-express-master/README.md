# Stripe-express
This repository is a basic intro of working with Stripe Connect, specifically express with PHP. 


## Step one
Run command `cp .env.example .env` to create your env file

## Step Two
Run command `composer install` to download your PHP packages

### Reference:
Please watch my video on this tutorial here: https://www.youtube.com/watch?v=mU46vpXR7_E
